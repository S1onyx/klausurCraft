package simon.klausurcraft.ui.home;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import simon.klausurcraft.task.Difficulty;

import java.util.EnumSet;
import java.util.Set;

public class HomeTopbarController {

    private HomeController root;

    @FXML private TextField searchField;
    @FXML private CheckBox fltEasy;
    @FXML private CheckBox fltMedium;
    @FXML private CheckBox fltHard;

    public void init(HomeController root) {
        this.root = root;

        // Prevent JavaFX from auto-focusing the search field at startup.
        searchField.setFocusTraversable(false);
        Platform.runLater(() -> searchField.setFocusTraversable(true));

        searchField.setTooltip(new Tooltip("Filter tasks by id, title, text, or solution."));
        fltEasy.setTooltip(new Tooltip("Show only subtasks with difficulty easy."));
        fltMedium.setTooltip(new Tooltip("Show only subtasks with difficulty medium."));
        fltHard.setTooltip(new Tooltip("Show only subtasks with difficulty hard."));

        // Attach semantic style classes so CSS can color them (IDs are not CSS ids).
        // This fixes the "grey checkboxes" issue.
        fltEasy.getStyleClass().addAll("difficulty-filter", "difficulty-easy");
        fltMedium.getStyleClass().addAll("difficulty-filter", "difficulty-medium");
        fltHard.getStyleClass().addAll("difficulty-filter", "difficulty-hard");

        // default all on
        fltEasy.setSelected(true);
        fltMedium.setSelected(true);
        fltHard.setSelected(true);

        // Re-render center on changes
        searchField.textProperty().addListener((obs, o, n) ->
            root.centerController.render(root.getTasks(), currentQuery(), allowedDifficulties())
        );
        fltEasy.selectedProperty().addListener((o, ov, nv) ->
            root.centerController.render(root.getTasks(), currentQuery(), allowedDifficulties())
        );
        fltMedium.selectedProperty().addListener((o, ov, nv) ->
            root.centerController.render(root.getTasks(), currentQuery(), allowedDifficulties())
        );
        fltHard.selectedProperty().addListener((o, ov, nv) ->
            root.centerController.render(root.getTasks(), currentQuery(), allowedDifficulties())
        );
    }

    String currentQuery() {
        String q = searchField.getText();
        return q == null ? "" : q.trim().toLowerCase();
    }

    Set<Difficulty> allowedDifficulties() {
        EnumSet<Difficulty> s = EnumSet.noneOf(Difficulty.class);
        if (fltEasy.isSelected()) s.add(Difficulty.EASY);
        if (fltMedium.isSelected()) s.add(Difficulty.MEDIUM);
        if (fltHard.isSelected()) s.add(Difficulty.HARD);
        if (s.isEmpty()) return EnumSet.allOf(Difficulty.class);
        return s;
    }

    void focusSearch() {
        if (searchField == null) return;
        searchField.requestFocus();
        searchField.selectAll();
    }
}
